# Discord Bot React Native Website & Next.js
<br>
<h3>WEBSITE THEME: https://astrabot.vercel.app/</h3>
<h3>UMUT BAYRAKTAR YOUTUBE: https://bit.ly/3zgizYR</h3>
<h3>CODE SHARE DISCORD: https://discord.gg/6XGqdgE</h3>
<hr>
<h3>
Discord Developers: https://discord.dev<br>
Discord Permission: https://bit.ly/3L4RZpi<br>
Download Visual Studio Code: https://code.visualstudio.com/download<br>
Download NodeJS V16: https://nodejs.org/<br>
MongoDB: https://mongodb.com<br>
Org Repo: https://bit.ly/3Q9KoI0</h3>
